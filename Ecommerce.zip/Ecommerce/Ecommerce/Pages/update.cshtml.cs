using Ecommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    [Authorize(Roles ="Admin")]
    public class updateModel : PageModel
    {
        public readonly Appdatacontxt _db;
        [BindProperty]
        public Product prod { get; set; }

        public updateModel(Appdatacontxt db)
        {
            _db = db;
        }
        public void OnGet(int? id)
        {
           var p = _db.prods.Find(id);
            if (p != null) {
                ViewData["name"] = p.name;
                ViewData["category"] = p.category;
                ViewData["price"] = p.price;
                ViewData["description"] = p.description;
            }
        }

        public IActionResult OnPost(int? id)
        {
            
            var pr = _db.prods.Find(id);
            if (pr != null)
            {
                pr.name = prod.name;
                pr.price= prod.price;
                pr.category = prod.category;    
                pr.image = prod.image;
                 _db.SaveChanges();
                 return RedirectToPage("/prodlist");
                
            }
            return Page();
        }
    }
}
