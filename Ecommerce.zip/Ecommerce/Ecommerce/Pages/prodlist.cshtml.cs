using Ecommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
   [Authorize(Roles="Admin")] 
    public class prodlistModel : PageModel
    {
        public List<Product> plist {get; set;}

        public readonly Appdatacontxt _db;
        

        public prodlistModel(Appdatacontxt db)
        {
            _db = db;
            plist = _db.prods.ToList();
        }
       

        public IActionResult OnGet(int? id)
        {
            plist = _db.prods.ToList();
            if (id != null)
            {
                var pid = _db.prods.Find(id);
                if (pid != null)
                {
                    _db.prods.Remove(pid);
                    _db.SaveChanges();
                }
                return RedirectToPage("prodlist");
            }
            return Page();
        }

      

       
    }
}
