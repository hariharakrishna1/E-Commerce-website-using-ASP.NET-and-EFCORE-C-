using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class showproductsModel : PageModel
    {
        public List<Product> plist { get; set; }

        public basket bas { get; set; }
        
        public basket b;

        public readonly Appdatacontxt _db;
        public showproductsModel(Appdatacontxt db)
        {
            _db = db;
            plist = _db.prods.ToList();
        }
        public IActionResult OnGet(int? id)
        {
            var prod = _db.prods.Find(id);
            b = new basket();//define a basket instance

            if (id != null)
            {
                if (prod != null)
                {   //check if product already exists
                    bas = _db.basket.FirstOrDefault(b => b.name == prod.name);
                    if (bas == null)
                    {
                        b.name = prod.name;
                        b.category = prod.category;
                        b.description = prod.description;
                        b.image = prod.image;
                        b.price = prod.price;
                        b.quantity = 1;//increase quantity
                        _db.basket.Add(b);//add details and update it to the DB
                        Response.WriteAsync("<script>alert('Product added');window.location.href = 'http://localhost:5044/showproducts';</script>");
                        //redirect on alerting user
                    }
                    else
                    {
                        ++bas.quantity; //increase existing product quantity if product exists
                        Response.WriteAsync("<script>alert('Product added');window.location.href = 'http://localhost:5044/showproducts';</script>");
                        //redirect on alerting user
                    }

                }
                _db.SaveChanges();
                
            }
            return Page();

        }
       

        }
    }

/*References
cart functions
https://learn.microsoft.com/en-us/aspnet/core/tutorials/first-mvc-app/

*/
