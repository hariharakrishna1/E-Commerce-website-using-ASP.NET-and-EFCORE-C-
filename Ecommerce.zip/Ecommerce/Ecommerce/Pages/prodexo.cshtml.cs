using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class prodexoModel : PageModel
    {
        public readonly Appdatacontxt _db;
        public List<review> review { get; set; }
        [BindProperty]
        public review r {  get; set; }  //bind review values from pageview into 'r' via bindproperty.

        public prodexoModel(Appdatacontxt db)
        {
            _db = db; 
        }
        public void OnGet(int? id)
        {
            var sum =0;
           
            var product = _db.prods.Find(id);

            //assign binding variables with desired product details. 

            ViewData["name"] = product.name;
            ViewData["description"] = product.description;
            ViewData["category"]= product.category;
            ViewData["price"]= product.price;
            ViewData["image"]= product.image;

            //find all reviews with assigned foreign key and convert into list!

            review=_db.rev.Where(x=> x.pid==product.id).ToList();

            for (var i = 0; i < review.Count(); i++)
            {
                sum += review[i].rating;
            }
           

        }

        public IActionResult OnPost(int? id)
        {
            r.pid = (int)id;//assign the products id to the foreign key of the matching record. 
            _db.rev.Add(r);
            _db.SaveChanges();
            return RedirectToPage("/prodexo",new { id = id });//send back to the same page
        }
    }
}
