using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class adminpageModel : PageModel
    {
        public readonly Appdatacontxt _db;
        public List<contacts> feedback {  get; set; }
        public adminpageModel(Appdatacontxt db)
        {
            _db = db;
            feedback=_db.contacts.ToList();

        }
        public void OnGet()
        {

        }
    }
}
