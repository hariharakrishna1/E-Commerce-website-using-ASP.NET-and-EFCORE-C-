using Ecommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    [Authorize(Roles ="user")]
    public class checkoutModel : PageModel
    {
        public readonly Appdatacontxt _db;
        [BindProperty]
        public contacts contact { get; set; }

        public checkoutModel(Appdatacontxt db)
        {
                _db = db;
        }
        public IActionResult OnPost()
        {
            _db.contacts.Add(contact);
           
            foreach (var item in _db.basket)
            {
                _db.basket.Remove(item);
                
            }
			_db.SaveChanges();
			return RedirectToPage("/Index");
        }
    }
}
