using Ecommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    
    public class basketModel : PageModel
    {
        public List<basket> plist {  get; set; }

        
        public readonly Appdatacontxt _db;
        public decimal sum = 0;

        public basketModel(Appdatacontxt db)
        {
            _db = db;
            plist = _db.basket.ToList();
        }
        public void OnGet(int? id)
        {
            var prod = _db.basket.Find(id);

            if (prod != null)
            {
               
                //if quantity is 0, remove the product from basket!
                if(prod.quantity == 0 || prod.quantity<0)
                {
                    _db.basket.Remove(prod);
                }
                prod.quantity -= 1;
            }
            ViewData["grandtotal"] = getsum();
            _db.SaveChanges();
        }

        //Get the Total price of the basket purchased!
        public decimal getsum()
        {
            plist = _db.basket.ToList();
            for (int i = 0; i < plist.Count; i++)
            {
                sum += plist[i].price * plist[i].quantity;
            }
            return sum;
        }
    }
}
