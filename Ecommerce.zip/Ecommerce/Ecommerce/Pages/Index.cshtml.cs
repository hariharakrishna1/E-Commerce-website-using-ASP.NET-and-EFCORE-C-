using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        [BindProperty]
        public string searchitem { get; set; }   
        public readonly Appdatacontxt _db;
        public List<Product> plist { get; set; }

        public IndexModel(ILogger<IndexModel> logger, Appdatacontxt db)
        {
            _logger = logger;
            _db = db;
           
        }

        public void OnGet()
        { 
             plist = _db.prods.ToList();
        }

        public IActionResult OnPost()
        {
            return RedirectToPage("/searchres", new { name=searchitem });
        }

        
      

    }
}
