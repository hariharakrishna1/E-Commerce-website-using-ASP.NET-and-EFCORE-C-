using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class productpgModel : PageModel
    {
        
        public readonly Appdatacontxt _db;
        
        public List<Product> plist { get; set; }
        public productpgModel(Appdatacontxt db)
        {
            _db = db;
        }
        public void OnGet(string? category)
        {
            ViewData["Searchitem"] = category;
            plist = _db.prods.Where(x=>x.category.Contains(category)).ToList();
        }
    }
}
