using Ecommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    [Authorize(Roles ="Admin")]
    public class createprodModel : PageModel
    {
        public readonly Appdatacontxt _db;

       
        public Product product;//dummy variable to check if product already exists
        [BindProperty]
        public Product prod { get; set; }

        public createprodModel(Appdatacontxt db)
        {
            _db =db;
        }
        public void OnGet()
        {
			ViewData["error"] = "Welcome!";
		}
        public IActionResult OnPost()
        {             

                _db.prods.Add(prod);
                _db.SaveChanges();
                return RedirectToPage("prodlist");
           
        }
    }
}
