using Ecommerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ecommerce.Pages
{
    public class searchresModel : PageModel
    {
        public List<Product> p;
        public readonly Appdatacontxt _db;



        [BindProperty]
        public List<Product> plist { get; set; }

        public searchresModel(Appdatacontxt db)
        {
            _db = db;
        }
        public void OnGet(string? name)
        {

            ViewData["Searchitem"] = name;
            plist = _db.prods.Where(x => x.name.Contains(name)).ToList();
        }
        public void OnPost() 
        { 
        
        }
    }
}
/*References

https://learn.microsoft.com/en-us/aspnet/core/tutorials/first-mvc-app/

*/