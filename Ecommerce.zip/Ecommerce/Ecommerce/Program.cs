using Ecommerce.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<Appdatacontxt>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

//builder.Services.AddDefaultIdentity<user>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<Appdatacontxt>();

//builder.Services.AddDefaultIdentity<user>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<Appdatacontxt>();

builder.Services.AddIdentity<user, IdentityRole>().AddDefaultTokenProviders().AddDefaultUI().AddEntityFrameworkStores<Appdatacontxt>();
// Add services to the container.
builder.Services.AddRazorPages();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");}
app.UseAuthentication();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
