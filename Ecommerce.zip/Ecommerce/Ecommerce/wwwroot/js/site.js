﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
let section = document.querySelector("section");
let cover_div = document.querySelector(".cover_div");
let openReg = document.querySelector(".openReg");
let log = document.querySelector(".login");


openReg.addEventListener("click", () => {
    cover_div.style.transform = "rotateY(180deg)";
    section.style.height = "550px";
    section.style.width = "250px;"
});

log.addEventListener("click", () => {
    cover_div.style.transform = "rotateY(0deg)";
    section.style.height = "400px"
});
//login page js ends here



//layout js code ends here




