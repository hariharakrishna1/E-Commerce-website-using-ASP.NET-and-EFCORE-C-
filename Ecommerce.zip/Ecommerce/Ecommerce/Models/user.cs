﻿using Microsoft.AspNetCore.Identity;

namespace Ecommerce.Models
{ 
    public class user:IdentityUser
    {
      
      
    }
}
