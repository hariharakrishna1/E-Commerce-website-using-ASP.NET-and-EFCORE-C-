﻿using System.ComponentModel.DataAnnotations;

namespace Ecommerce.Models
{
    public class review
    {
        
        public int id { get; set; }
        
        public int rating {  get; set; }

        public string comments { get; set; }

        public int pid { get; set; }    
       
    }
}
