﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce.Models
{
    public class Appdatacontxt:IdentityDbContext<user>
    {
        public Appdatacontxt(DbContextOptions<Appdatacontxt> options) :base(options)
        { 

        }
        public DbSet<Ecommerce.Models.Product> prods{ get; set;}
       
        public DbSet<Ecommerce.Models.basket> basket { get; set; }

        public DbSet<Ecommerce.Models.review> rev { get; set; }

        public DbSet<contacts> contacts { get; set; }
    }
}
