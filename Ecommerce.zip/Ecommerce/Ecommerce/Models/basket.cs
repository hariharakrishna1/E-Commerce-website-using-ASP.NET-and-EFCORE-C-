﻿namespace Ecommerce.Models
{
    public class basket
    {
        public int id { get; set; }
        public string name { get; set; }
        public decimal price { get; set; }
        public string description { get; set; }
        public string category { get; set; }
        public string image { get; set; }
        public int quantity { get; set; }
    }

    
}
